return{
	
	{
		["name"] = "半夏",
		["prefab"] = "fwd_in_pdt_plant_pinellia_ternata_seed",
		["cost"] = 20.0,
		["num2give"] = 5.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "紫菀",
		["prefab"] = "fwd_in_pdt_plant_aster_tataricus_l_f_seed",
		["cost"] = 20.0,
		["num2give"] = 5.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "苍术",
		["prefab"] = "fwd_in_pdt_plant_atractylodes_macrocephala_seed",
		["cost"] = 20.0,
		["num2give"] = 5.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "未开封的书籍",
		["prefab"] = "fwd_in_pdt_item_locked_book",
		["cost"] = 40.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "咖啡丛",
		["prefab"] = "fwd_in_pdt_plant_coffeebush_item",
		["cost"] = 20.0,
		["num2give"] = 1.0,
		["image"] = "fwd_in_pdt_plant_coffeebush_item.tex",
		["atlas"] = "images/inventoryimages/fwd_in_pdt_plant_coffeebush_item.xml"
	},
	{
		["name"] = "芒果接穗",
		["prefab"] = "fwd_in_pdt_plant_mango_tree_item",
		["cost"] = 150.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "大豆种子",
		["prefab"] = "fwd_in_pdt_plant_bean_seed",
		["cost"] = 20.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "橙子种子",
		["prefab"] = "fwd_in_pdt_plant_orange_seed",
		["cost"] = 20.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "坎普斯背包",
		["prefab"] = "krampus_sack",
		["cost"] = 500.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "混沌万能锅碎片",
		["prefab"] = "fwd_in_pdt_material_chaotic_cookpot_puzzle_1",
		["cost"] = 100.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "混沌万能锅碎片",
		["prefab"] = "fwd_in_pdt_material_chaotic_cookpot_puzzle_2",
		["cost"] = 100.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "混沌万能锅碎片",
		["prefab"] = "fwd_in_pdt_material_chaotic_cookpot_puzzle_3",
		["cost"] = 100.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "混沌万能锅碎片",
		["prefab"] = "fwd_in_pdt_material_chaotic_cookpot_puzzle_4",
		["cost"] = 100.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	}
}
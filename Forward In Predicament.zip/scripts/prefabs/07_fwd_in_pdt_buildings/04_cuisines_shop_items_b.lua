return{
	
	{
		["name"] = "",
		["prefab"] = "shroomcake",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "vegstinger",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "bananajuice",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "bunnystew",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "bonestew",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "meatballs",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "kabobs",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "honeyham",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "honeynuggets",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "surfnturf",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "seafoodgumbo",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "fishsticks",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "honeynuggets",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "surfnturf",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "seafoodgumbo",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "fishsticks",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "californiaroll",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "fishtacos",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "ceviche",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "unagi",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "lobsterdinner",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "lobsterbisque",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "barnaclestuffedfishhead",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "barnaclinguine",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "barnaclepita",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "barnaclesushi",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "turkeydinner",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "baconeggs",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "perogies",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "hotchili",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "pepperpopper",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "frogglebunwich",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "guacamole",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "monsterlasagna",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "mandrakesoup",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "sweettea",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "mashedpotatoes",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "potatotornado",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "pumpkincookie",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "stuffedeggplant",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "salsa",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "ratatouille",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "asparagussoup",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "flowersalad",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "trailmix",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "fruitmedley",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "jammypreserves",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "dragonpie",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "leafloaf",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "leafymeatburger",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "leafymeatsouffle",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "meatysalad",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "bananapop",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "watermelonicle",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "icecream",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "waffles",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "butterflymuffin",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "powcake",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "taffy",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "moqueca",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "freshfruitcrepes",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "bonesoup",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "koalefig_trunk",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "frozenbananadaiquiri",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "frognewton",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "figkabab",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "figatoni",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "monstertartare",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "glowberrymousse",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "potatosouffle",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "frogfishbowl",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "gazpacho",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "dragonchilisalad",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "nightmarepie",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "justeggs",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "veggieomlet",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "talleggs",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "",
		["prefab"] = "beefalotreat",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	}
}
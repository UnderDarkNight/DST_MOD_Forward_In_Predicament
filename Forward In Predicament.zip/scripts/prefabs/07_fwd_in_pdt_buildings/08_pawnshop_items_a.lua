return{
	
	{
		["name"] = "唤星者魔杖",
		["prefab"] = "yellowstaff",
		["cost"] = 1.0,
		["num2give"] = 20.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "拆解魔杖",
		["prefab"] = "greenstaff",
		["cost"] = 1.0,
		["num2give"] = 20.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "恢复魔杖",
		["prefab"] = "fwd_in_pdt_equipment_repair_staff",
		["cost"] = 1.0,
		["num2give"] = 20.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "龙鳞皮",
		["prefab"] = "dragon_scales",
		["cost"] = 1.0,
		["num2give"] = 10.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "熊皮",
		["prefab"] = "bearger_fur",
		["cost"] = 1.0,
		["num2give"] = 10.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "巨鹿眼球",
		["prefab"] = "deerclops_eyeball",
		["cost"] = 1.0,
		["num2give"] = 10.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "铥矿",
		["prefab"] = "thulecite",
		["cost"] = 5.0,
		["num2give"] = 5.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "紫宝石",
		["prefab"] = "purplegem",
		["cost"] = 10.0,
		["num2give"] = 50.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "蓝宝石",
		["prefab"] = "bluegem",
		["cost"] = 10.0,
		["num2give"] = 10.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "红宝石",
		["prefab"] = "redgem",
		["cost"] = 10.0,
		["num2give"] = 10.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "绿宝石",
		["prefab"] = "greengem",
		["cost"] = 10.0,
		["num2give"] = 50.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "橙宝石",
		["prefab"] = "orangegem",
		["cost"] = 10.0,
		["num2give"] = 10.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "黄宝石",
		["prefab"] = "yellowgem",
		["cost"] = 10.0,
		["num2give"] = 50.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "麋鹿鹅羽毛",
		["prefab"] = "goose_feather",
		["cost"] = 1.0,
		["num2give"] = 10.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "海象牙",
		["prefab"] = "walrus_tusk",
		["cost"] = 1.0,
		["num2give"] = 10.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "伏特羊角",
		["prefab"] = "lightninggoathorn",
		["cost"] = 1.0,
		["num2give"] = 5.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "伏特羊角冻",
		["prefab"] = "voltgoatjelly",
		["cost"] = 1.0,
		["num2give"] = 5.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "彩虹糖豆",
		["prefab"] = "jellybean",
		["cost"] = 1.0,
		["num2give"] = 5.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "杨枝甘露",
		["prefab"] = "fwd_in_pdt_food_mango_ice_drink",
		["cost"] = 1.0,
		["num2give"] = 5.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "药酒（棱镜）",
		["prefab"] = "dish_medicinalliquor",
		["cost"] = 1.0,
		["num2give"] = 20.0,
		["image"] = "dish_medicinalliquor.tex",
		["atlas"] = "images/inventoryimages/dish_medicinalliquor.xml"
	}
}
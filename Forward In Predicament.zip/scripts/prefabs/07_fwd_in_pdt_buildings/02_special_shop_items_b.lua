return{
	
	{
		["name"] = "草格地皮",
		["prefab"] = "turf_fwd_in_pdt_turf_grasslawn",
		["cost"] = 10.0,
		["num2give"] = 10.0,
		["image"] = "fwd_in_pdt_turf_grasslawn.tex",
		["atlas"] = "images/inventoryimages/fwd_in_pdt_turf_grasslawn.xml"
	},
	{
		["name"] = "砖块地毯（移植）",
		["prefab"] = "turf_fwd_in_pdt_turf_cobbleroad",
		["cost"] = 10.0,
		["num2give"] = 10.0,
		["image"] = "fwd_in_pdt_turf_cobbleroad.tex",
		["atlas"] = "images/inventoryimages/fwd_in_pdt_turf_cobbleroad.xml"
	},
	{
		["name"] = "复制蛇皮地毯",
		["prefab"] = "turf_fwd_in_pdt_turf_snakeskin",
		["cost"] = 10.0,
		["num2give"] = 10.0,
		["image"] = "fwd_in_pdt_turf_snakeskin.tex",
		["atlas"] = "images/inventoryimages/fwd_in_pdt_turf_snakeskin.xml"
	},
	{
		["name"] = "蛇皮",
		["prefab"] = "fwd_in_pdt_material_snake_skin",
		["cost"] = 10.0,
		["num2give"] = 5.0,
		["image"] = "",
		["atlas"] = ""
	}
}
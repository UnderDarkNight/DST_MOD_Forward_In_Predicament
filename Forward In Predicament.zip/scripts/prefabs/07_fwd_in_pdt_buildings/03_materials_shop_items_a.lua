return{
	
	{
		["name"] = "龙鳞皮",
		["prefab"] = "dragon_scales",
		["cost"] = 20.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "熊皮",
		["prefab"] = "bearger_fur",
		["cost"] = 20.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "巨鹿眼球",
		["prefab"] = "deerclops_eyeball",
		["cost"] = 20.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "铥矿",
		["prefab"] = "thulecite",
		["cost"] = 10.0,
		["num2give"] = 5.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "紫宝石",
		["prefab"] = "purplegem",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "蓝宝石",
		["prefab"] = "bluegem",
		["cost"] = 5.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "红宝石",
		["prefab"] = "redgem",
		["cost"] = 5.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "绿宝石",
		["prefab"] = "greengem",
		["cost"] = 30.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "橙宝石",
		["prefab"] = "orangegem",
		["cost"] = 10.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "黄宝石",
		["prefab"] = "yellowgem",
		["cost"] = 40.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "麋鹿鹅羽毛",
		["prefab"] = "goose_feather",
		["cost"] = 20.0,
		["num2give"] = 5.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "木板",
		["prefab"] = "boards",
		["cost"] = 10.0,
		["num2give"] = 5.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "石砖",
		["prefab"] = "cutstone",
		["cost"] = 10.0,
		["num2give"] = 5.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "活木",
		["prefab"] = "livinglog",
		["cost"] = 10.0,
		["num2give"] = 3.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "海象牙",
		["prefab"] = "walrus_tusk",
		["cost"] = 30.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "蜂刺",
		["prefab"] = "stinger",
		["cost"] = 10.0,
		["num2give"] = 20.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "蜘蛛丝",
		["prefab"] = "silk",
		["cost"] = 10.0,
		["num2give"] = 5.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "伏特羊角",
		["prefab"] = "lightninggoathorn",
		["cost"] = 20.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	}
}
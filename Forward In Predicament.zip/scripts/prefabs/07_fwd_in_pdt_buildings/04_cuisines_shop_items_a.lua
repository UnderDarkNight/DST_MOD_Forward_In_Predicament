return{
	
	{
		["name"] = "伏特羊角冻",
		["prefab"] = "voltgoatjelly",
		["cost"] = 30.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "彩虹糖豆",
		["prefab"] = "jellybean",
		["cost"] = 20.0,
		["num2give"] = 2.0,
		["image"] = "",
		["atlas"] = ""
	},
	{
		["name"] = "杨枝甘露",
		["prefab"] = "fwd_in_pdt_food_mango_ice_drink",
		["cost"] = 60.0,
		["num2give"] = 1.0,
		["image"] = "",
		["atlas"] = ""
	}
}
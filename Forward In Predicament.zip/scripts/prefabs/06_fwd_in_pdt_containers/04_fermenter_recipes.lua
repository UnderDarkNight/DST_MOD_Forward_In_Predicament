return {
    --- 生牛奶
        ["fwd_in_pdt_food_raw_milk"] = {            
            product = "fwd_in_pdt_food_yogurt",
            num = 2 ,
        },
    --- 电羊奶
        ["goatmilk"] = {
            product = "fwd_in_pdt_food_yogurt",
            num = 2 ,
        },
    --- 鸟蛋
        ["bird_egg"] = {
            product = "fwd_in_pdt_food_thousand_year_old_egg",
            num = 1 ,
        },
    --- 高脚鸟蛋
        ["tallbirdegg"] = {
            product = "fwd_in_pdt_food_thousand_year_old_egg",
            num = 3 ,
        },
    --- 豆腐
        ["fwd_in_pdt_food_tofu"] = {
            product = "fwd_in_pdt_food_stinky_tofu",
            num = 4 ,
        },

}
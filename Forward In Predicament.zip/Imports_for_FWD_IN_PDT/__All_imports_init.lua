

modimport("Imports_for_FWD_IN_PDT/00_load_Assets.lua")	---- 加载mod 所用素材资源
modimport("Imports_for_FWD_IN_PDT/01_mod_config.lua")	---- 加载mod 设置

modimport("Imports_for_FWD_IN_PDT/02_00_Strings_Table_CH.lua")	---- 中文语言
modimport("Imports_for_FWD_IN_PDT/02_01_Strings_Table_EN.lua")	---- 英文语言


modimport("Imports_for_FWD_IN_PDT/03_TUNING_Common_Func.lua")	---- 常用函数

modimport("Imports_for_FWD_IN_PDT/04_DST_STRINGS_PRE_INIT_.lua")	---- 尝试初始化部分变量名字。后缀名字注意


modimport("Imports_for_FWD_IN_PDT/05_Chat_Message_Icons.lua")	---- 添加 聊天框密语系统用的图标

modimport("Imports_for_FWD_IN_PDT/06_inventoryimages_icon_register.lua")	---- 物品图标统一注册
modimport("Imports_for_FWD_IN_PDT/07_minimap_icon_register.lua")	        ---- 地图图标统一注册


modimport("Imports_for_FWD_IN_PDT/08_componentactions_crash_fix.lua")	        ---- 尝试做个补丁

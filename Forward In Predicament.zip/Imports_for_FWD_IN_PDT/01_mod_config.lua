TUNING["Forward_In_Predicament.Config"] = {}
TUNING["Forward_In_Predicament.Config"].Language = GetModConfigData("LANGUAGE")

TUNING["Forward_In_Predicament.Config"].compatibility_mode = GetModConfigData("compatibility_mode")


TUNING["Forward_In_Predicament.Config"].UI_FX = GetModConfigData("UI_FX")     --- UI的动画特效




TUNING["Forward_In_Predicament.Config"].Element_Core_Probability = GetModConfigData("Element_Core_Probability")     --- UI的动画特效
TUNING["Forward_In_Predicament.Config"].ATM_CROSS_ARCHIVE = GetModConfigData("ATM_CROSS_ARCHIVE")     --- 跨存档ATM






-- TUNING.FWD_IN_PDT_MOD___DEBUGGING_MODE = true	
-- 这个文件是分类入口
-- 本lua 和 modmain.lua 平级
-- 注意文件路径

---- 多版本调试用的 debug 模块，正式上限功能后从这个类里移除


-- modimport("Key_Modules_Of_FWD_IN_PDT/_Debugging_Modules/00_whip_Action.lua")    --- 添加自定义交互动作


-- modimport("Key_Modules_Of_FWD_IN_PDT/_Debugging_Modules/02_rpc_event_test.lua")    --- 
modimport("Key_Modules_Of_FWD_IN_PDT/_Debugging_Modules/01_player_death.lua")    --- 
modimport("Key_Modules_Of_FWD_IN_PDT/_Debugging_Modules/02_pigking_upgrade.lua")    --- 
-- modimport("Key_Modules_Of_FWD_IN_PDT/_Debugging_Modules/03_player_in_dark_Charlie.lua")    --- 


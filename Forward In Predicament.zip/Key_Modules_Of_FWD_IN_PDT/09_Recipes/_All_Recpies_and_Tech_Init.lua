-- 这个文件是分类入口
-- 本lua 和 modmain.lua 平级
-- 注意文件路径


modimport("Key_Modules_Of_FWD_IN_PDT/09_Recipes/01_buildings.lua")    --- 添加建筑类

modimport("Key_Modules_Of_FWD_IN_PDT/09_Recipes/02_medical_check_up_machine.lua")    --- 健康检查机及其科技树

modimport("Key_Modules_Of_FWD_IN_PDT/09_Recipes/03_element_core_weapon_recipes_for_green_staff.lua")    --- 给绿色法杖拆元素装备用的






-- 这个文件是分类入口
-- 本lua 和 modmain.lua 平级
-- 注意文件路径

-- modimport("Key_Modules_Of_FWD_IN_PDT/01_02_Ohter_Original_Prefabs_Upgrade/01_amulet_upgrade.lua")    --- 升级项链

modimport("Key_Modules_Of_FWD_IN_PDT/01_02_Ohter_Original_Prefabs_Upgrade/00_special_ent_add_tag.lua")    --- 上 tag 好扫描

-- modimport("Key_Modules_Of_FWD_IN_PDT/01_02_Ohter_Original_Prefabs_Upgrade/01_spear.lua")    --- 升级 长矛 

-- modimport("Key_Modules_Of_FWD_IN_PDT/01_02_Ohter_Original_Prefabs_Upgrade/02_nightmaresword.lua")    --- 升级 暗影剑 

-- modimport("Key_Modules_Of_FWD_IN_PDT/01_02_Ohter_Original_Prefabs_Upgrade/03_hambat.lua")    --- 升级 火腿棒 

-- modimport("Key_Modules_Of_FWD_IN_PDT/01_02_Ohter_Original_Prefabs_Upgrade/04_green_staff.lua")    --- 升级 分解法杖 

modimport("Key_Modules_Of_FWD_IN_PDT/01_02_Ohter_Original_Prefabs_Upgrade/05_star_moon_staffs_upgreade.lua")    --- 升级 唤月/唤星 法杖 

modimport("Key_Modules_Of_FWD_IN_PDT/01_02_Ohter_Original_Prefabs_Upgrade/06_boss_toadstool_upgrade.lua")    --- 修改 蟾蜍BOSS

modimport("Key_Modules_Of_FWD_IN_PDT/01_02_Ohter_Original_Prefabs_Upgrade/07_spidergland_and_healingsalve_for_spider_poison.lua")    --- 修改 蜘蛛腺体 和 治疗膏药

modimport("Key_Modules_Of_FWD_IN_PDT/01_02_Ohter_Original_Prefabs_Upgrade/08_rock_flintless.lua")    --- 修改 岩石，可以挖到雄黄矿

modimport("Key_Modules_Of_FWD_IN_PDT/01_02_Ohter_Original_Prefabs_Upgrade/09_mutant_frogs.lua")    --- 修改 青蛙，让青蛙能变异

modimport("Key_Modules_Of_FWD_IN_PDT/01_02_Ohter_Original_Prefabs_Upgrade/10_pig_house.lua")    --- 修改 猪人房子

modimport("Key_Modules_Of_FWD_IN_PDT/01_02_Ohter_Original_Prefabs_Upgrade/11_beefalo.lua")    --- 修改 牛

modimport("Key_Modules_Of_FWD_IN_PDT/01_02_Ohter_Original_Prefabs_Upgrade/12_razor.lua")    --- 修改 剃刀，使用有概率出血

modimport("Key_Modules_Of_FWD_IN_PDT/01_02_Ohter_Original_Prefabs_Upgrade/13_evergreen_tree.lua")    --- 修改 常青树

modimport("Key_Modules_Of_FWD_IN_PDT/01_02_Ohter_Original_Prefabs_Upgrade/14_cookpot_upgrade_2_chaotic_type.lua")    --- 修改 烹饪锅，可以用【混沌眼球】升级

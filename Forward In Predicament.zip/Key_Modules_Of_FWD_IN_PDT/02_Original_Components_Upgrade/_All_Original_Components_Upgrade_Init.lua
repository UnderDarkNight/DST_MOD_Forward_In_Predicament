-- 这个文件是分类入口
-- 本lua 和 modmain.lua 平级
-- 注意文件路径
-------- 本文件用于 hook com 组件 和 replica 组件

-- modimport("Key_Modules_Of_FWD_IN_PDT/02_Original_Components_Upgrade/01_Attribute_Damage_System.lua")        --- 属性伤害分类组件



















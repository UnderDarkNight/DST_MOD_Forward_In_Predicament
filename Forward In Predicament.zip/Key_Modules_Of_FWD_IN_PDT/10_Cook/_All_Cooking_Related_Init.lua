-- 这个文件是分类入口
-- 本lua 和 modmain.lua 平级
-- 注意文件路径


modimport("Key_Modules_Of_FWD_IN_PDT/10_Cook/00_make_food_can_go_into_cookport.lua")    --- 把原本不能进烹饪锅的东西添加进去

modimport("Key_Modules_Of_FWD_IN_PDT/10_Cook/01_cooked_foods_recipes.lua")    --- 食物配方



modimport("Key_Modules_Of_FWD_IN_PDT/10_Cook/02_portablespicer.lua")    --- 便携香料站 可放入其他特殊物品
modimport("Key_Modules_Of_FWD_IN_PDT/10_Cook/03_portablespicer_recipes.lua")    --- 便携香料站 配方


modimport("Key_Modules_Of_FWD_IN_PDT/10_Cook/04_special_cookpot_recipes.lua")    --- 万能锅配方注册








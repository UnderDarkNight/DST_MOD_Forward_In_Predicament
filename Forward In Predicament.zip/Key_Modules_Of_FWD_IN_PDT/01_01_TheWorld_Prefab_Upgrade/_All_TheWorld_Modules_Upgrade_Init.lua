-- 这个文件是分类入口
-- 本lua 和 modmain.lua 平级
-- 注意文件路径
modimport("Key_Modules_Of_FWD_IN_PDT/01_01_TheWorld_Prefab_Upgrade/00_theworld_upgrade.lua")    
--- 基础组件添加和初始化

modimport("Key_Modules_Of_FWD_IN_PDT/01_01_TheWorld_Prefab_Upgrade/01_theworld_player_spawner.lua")    
--- 玩家出生点相关的API操作




layers = {
    {
      type = "tilelayer",   
      name = "块层 1",   
      x = 0,   
      y = 0,   
      width = 19,   
      height = 19,   
      visible = true,   
      opacity = 1,   
      properties = {},   
      encoding = "lua",   
      data = {
        0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   
        0,   0,carp,carp,   0,   0,   0,   0,   0,   0,   0,   0,   0,cobb,cobb,   0,   0,   0,   0,   
        0,carp,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,cobb,cobb,   0,   0,   
        0,carp,   0,carp,   0,redt,redt,redt,redt,redt,redt,redt,   0,carp,   0,cobb,cobb,   0,   0,   
        0,carp,   0,   0,   0,redt,cobb,cobb,cobb,cobb,cobb,redt,   0,   0,   0,cobb,cobb,   0,   0,   
        0,   0,   0,   0,redt,redt,cobb,lawn,lawn,lawn,cobb,redt,redt,   0,   0,   0,cobb,   0,   0,   
        0,   0,   0,   0,redt,cobb,lawn,snak,lawn,snak,lawn,cobb,redt,   0,   0,   0,   0,cobb,   0,   
        0,   0,   0,   0,redt,cobb,lawn,snak,lawn,snak,lawn,cobb,redt,   0,   0,   0,   0,cobb,   0,   
        0,   0,   0,   0,redt,cobb,lawn,snak,lawn,snak,lawn,cobb,redt,   0,   0,   0,cobb,   0,   0,   
        0,   0,   0,   0,redt,cobb,cobb,lawn,lawn,lawn,cobb,cobb,redt,cobb,cobb,cobb,   0,   0,   0,   
        0,   0,   0,   0,redt,cobb,lawn,snak,lawn,snak,lawn,cobb,redt,   0,   0,   0,cobb,   0,   0,   
        0,   0,   0,   0,redt,cobb,lawn,snak,lawn,snak,lawn,cobb,redt,   0,   0,   0,   0,cobb,   0,   
        0,   0,   0,   0,redt,cobb,lawn,snak,lawn,snak,lawn,cobb,redt,   0,   0,   0,   0,cobb,   0,   
        0,   0,   0,   0,redt,redt,cobb,lawn,lawn,lawn,cobb,redt,redt,   0,   0,   0,cobb,   0,   0,   
        0,carp,   0,   0,   0,redt,cobb,cobb,cobb,cobb,cobb,redt,   0,   0,   0,cobb,cobb,   0,   0,   
        0,carp,   0,carp,   0,redt,redt,redt,redt,redt,redt,redt,   0,carp,   0,cobb,cobb,   0,   0,   
        0,carp,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,cobb,cobb,   0,   0,   
        0,   0,carp,carp,   0,   0,   0,   0,   0,   0,   0,   0,   0,cobb,cobb,   0,   0,   0,   0,   
        0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
      }
    }
  }
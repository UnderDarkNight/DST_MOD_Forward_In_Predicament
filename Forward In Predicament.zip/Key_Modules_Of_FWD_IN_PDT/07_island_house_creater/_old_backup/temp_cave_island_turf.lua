layers = {
  {
    type = "tilelayer",   
    name = "块层 1",   
    x = 0,   
    y = 0,   
    width = 23,   
    height = 13,   
    visible = true,   
    opacity = 1,   
    properties = {},   
    encoding = "lua",   
    data = {
      0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   
      0,road,road,road,road,road,road,road,   0,   0,   0,   0,   0,   0,   0,roky,roky,roky,   0,   0,   0,   0,   0,   
      0,road,road,road,road,road,road,road,   0,   0,   0,   0,   0,   0,roky,   0,NONE,   0,roky,   0,   0,   0,   0,   
      0,road,road,road,road,road,road,road,   0,   0,   0,   0,   0,roky,   0,NONE,NONE,NONE,   0,roky,   0,   0,   0,   
      0,road,road,road,road,road,road,road,road,road,road,road,road,roky,NONE,NONE,redt,NONE,NONE,   0,roky,   0,   0,   
      0,road,road,road,road,road,road,road,   0,   0,   0,   0,   0,roky,   0,NONE,NONE,NONE,   0,roky,   0,   0,   0,   
      0,road,road,road,road,road,road,road,   0,   0,   0,   0,   0,   0,roky,   0,NONE,   0,roky,   0,NONE,   0,   0,   
      0,road,road,road,road,road,road,road,   0,   0,   0,   0,   0,   0,   0,roky,roky,roky,   0,NONE,NONE,   0,   0,   
      0,   0,   0,   0,road,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   
      0,   0,   0,   0,road,   0,   0,ruin,ruin,ruin,ruin,ruin,ruin,ruin,ruin,ruin,ruin,ruin,   0,   0,   0,   0,   0,   
      0,   0,   0,   0,road,road,road,ruin,ruin,ruin,ruin,ruin,ruin,ruin,ruin,ruin,ruin,ruin,   0,   0,   0,   0,   0,   
      0,   0,   0,   0,   0,   0,   0,ruin,ruin,ruin,ruin,ruin,ruin,ruin,ruin,ruin,ruin,ruin,   0,   0,   0,   0,   0,   
      0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
    }
  }
}